<?php
	DEFINE( 'MERCHANT_ID', '45487140921333' ); // Merchant ID
	DEFINE( 'ACCESS_KEY', 'epYTszJ8fqVGlrDpf0Yt' ); // Certificate key

	DEFINE( 'PROXY_HOST', null); // Proxy URL (optional)
	DEFINE( 'PROXY_PORT', null); // Proxy port number without 'quotes' (optional)
	DEFINE( 'PROXY_LOGIN', '' ); // Proxy login (optional)
	DEFINE( 'PROXY_PASSWORD', '' ); // Proxy password (optional)

	DEFINE( 'PRODUCTION', FALSE); // Demonstration (FALSE) or production (TRUE) mode
?>